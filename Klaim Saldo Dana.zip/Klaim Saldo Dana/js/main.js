document.addEventListener("DOMContentLoaded", () => {
  // --- Konfigurasi ---
  const TESTIMONIAL_INTERVAL = 5000; // Interval ganti testimoni (5 detik)
  const COUNTDOWN_SECONDS = 59;      // Durasi countdown

  // --- Elemen DOM yang Digunakan ---
  const timerEl = document.getElementById("timer");
  const testiNameEl = document.getElementById("testi-name");
  const testiTextEl = document.getElementById("testi-text");
  const testiImgEl = document.querySelector(".testimonial-avatar");
  const testiBoxEl = document.getElementById("testimonial-box");

  // --- Inisialisasi Skrip ---
  startCountdown(COUNTDOWN_SECONDS, timerEl);
  setupTestimonials(
    "assets/testimonials.json",
    testiNameEl,
    testiTextEl,
    testiImgEl,
    testiBoxEl,
    TESTIMONIAL_INTERVAL
  );
});

/**
 * Fungsi untuk memulai countdown palsu yang terus berulang.
 * @param {number} duration - Durasi dalam detik.
 * @param {HTMLElement} element - Elemen HTML untuk menampilkan timer.
 */
function startCountdown(duration, element) {
  if (!element) return; // Hentikan fungsi jika elemen tidak ditemukan
  
  let seconds = duration;

  setInterval(() => {
    seconds--;
    if (seconds < 0) {
      seconds = duration; // Ulangi countdown jika sudah habis
    }
    // Format waktu agar selalu dua digit (e.g., 09, 08, 07)
    element.textContent = `00:${seconds < 10 ? '0' : ''}${seconds}`;
  }, 1000);
}

/**
 * Fungsi untuk mengambil dan menampilkan testimoni secara acak dan periodik.
 * @param {string} dataUrl - URL ke file JSON testimoni (e.g., "assets/testimonials.json").
 * @param {HTMLElement} nameEl - Elemen untuk nama testimoni.
 * @param {HTMLElement} textEl - Elemen untuk teks testimoni.
 * @param {HTMLElement} imgEl - Elemen untuk gambar testimoni.
 * @param {HTMLElement} boxEl - Elemen container testimoni untuk efek fade.
 * @param {number} interval - Interval pergantian dalam milidetik.
 */
async function setupTestimonials(dataUrl, nameEl, textEl, imgEl, boxEl, interval) {
  // Hentikan fungsi jika salah satu elemen penting tidak ditemukan
  if (!nameEl || !textEl || !imgEl || !boxEl) return;

  try {
    const response = await fetch(dataUrl);
    if (!response.ok) {
      throw new Error(`Gagal memuat data testimoni: ${response.statusText}`);
    }
    const testimonials = await response.json();

    const updateTestimonial = () => {
      // Pilih testimoni secara acak dari data
      const randomIndex = Math.floor(Math.random() * testimonials.length);
      const selectedTesti = testimonials[randomIndex];
      
      // Acak gambar avatar dari pravatar
      const randomImgId = Math.floor(Math.random() * 70) + 1;

      // Tambahkan class untuk efek fade-out
      boxEl.classList.add('fade-out');

      // Tunggu animasi fade-out selesai, baru ganti kontennya
      setTimeout(() => {
        nameEl.textContent = selectedTesti.name;
        textEl.textContent = `"${selectedTesti.quote}"`;
        imgEl.src = `https://i.pravatar.cc/50?img=${randomImgId}`;
        imgEl.alt = `Foto profil ${selectedTesti.name}`; // Update alt text untuk aksesibilitas
        
        // Hapus class untuk memicu animasi fade-in
        boxEl.classList.remove('fade-out');
      }, 500); // Waktu ini harus cocok dengan durasi transisi di CSS
    };

    // Tampilkan testimoni pertama kali saat halaman dimuat
    updateTestimonial();
    // Atur interval untuk mengganti testimoni secara berkala
    setInterval(updateTestimonial, interval);

  } catch (error) {
    console.error("Tidak dapat memuat testimoni:", error);
    // Tampilkan pesan error di halaman jika data gagal dimuat
    nameEl.textContent = "Gagal memuat testimoni.";
    textEl.textContent = "Silakan periksa koneksi atau muat ulang halaman.";
  }
}